//
//  NumberTheory12ViewController.swift
//  Freiheit
//
//  Created by Usuario1 on 27/05/21.
//

import UIKit

class NumberTheory12ViewController: UIViewController {
    
    @IBOutlet var TopicTitleText1: UILabel!
    @IBOutlet var Text1: UILabel!
    
    @IBOutlet var TopicTitleText2: UILabel!
    @IBOutlet var Text2: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        updateUI()
        
    }
    
    func updateUI() {
        
        TopicTitleText1.text = "Representations"
        Text1.text = "Lines are very usefull in many ways. From hysics to ingeniering, we use it to linear algebra, geometry, calculus, and viele fields more. Also, its fundamental to computational science. \n Maybe you haven't hear about that, but we need that to understand vectors, derivatives, and a lot things more. "
        
        TopicTitleText2.text = "Mathematica way"
        Text2.text = "In this course we're gonna see how a line works and make possible a lot of things. Beginning with kwnowing the dot notation in cartesian plane, the line equation, a first simple view of the line and a work of write lines equations. "
    }
    
}


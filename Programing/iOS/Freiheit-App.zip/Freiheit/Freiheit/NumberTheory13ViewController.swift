import UIKit

class NumberTheory13ViewController: UIViewController {

    @IBOutlet var TitleText1: UILabel!
    @IBOutlet var Text1: UILabel!
    
    @IBOutlet var TitleText2: UILabel!
    @IBOutlet var Text2: UILabel!
    
    @IBOutlet var TitleText3: UILabel!
    @IBOutlet var Text3: UILabel!
    
    @IBOutlet var TitleText4: UILabel!
    @IBOutlet var Text4: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
        
    }

    func updateUI() {
        TitleText1.text = "Introduction"
        Text1.text = "All linear equations can be represented by an independent variable (denoted by x) and another dependent variable (denoted by y) in a relationship of y=y(x). The linear equation has three forms wich can be modelated. Each one give the same result, but they are easy to obtain depending of what data we have of them. The three representaions are: The general form; the dot-slope form, and the slope-intersection form."
        
        TitleText2.text = "Representation: General form"
        Text2.text = "In the general form, que take 2 constants: B,C, that determinated the behaviour of the line. The equation that represent a line have the form: y+Bx+C=0. In wich: -B is the slope of the line, and -C the intersection with the y-axis."
        
        TitleText3.text = "Representation: dot-slope"
        Text3.text = "In the dot-slope form, we take a point: (x_0,y_0) where the line pass through. Also, we take the slope m. With that, the equation that represent a line have the form: (y-y_0)/(x-x_0)=m."
        
        TitleText4.text = "Representation: slope-intersection "
        Text4.text = "In the slope-intersection form, we have to know the slope m, and the intersection with the y-axis of the line b. With that, the equation that represent a line have the form: y=mx+b"
        
    }

}

import UIKit

class NumberTheoryViewController: UIViewController {

    @IBOutlet var BackButton: UIButton!
    
    @IBOutlet var LabelTopic1: UILabel!
    @IBOutlet var ButtonToppic11: UIButton!
    @IBOutlet var ButtonToppic12: UIButton!
    @IBOutlet var ButtonToppic13: UIButton!
    @IBOutlet var ButtonToppic14: UIButton!
    @IBOutlet var ButtonToppic15: UIButton!
    @IBOutlet var ButtonToppic16: UIButton!
    
    @IBOutlet var LabelTopic2: UILabel!
    @IBOutlet var ButtonToppic21: UIButton!
    @IBOutlet var ButtonToppic22: UIButton!
    @IBOutlet var ButtonToppic23: UIButton!
    @IBOutlet var ButtonToppic24: UIButton!
    @IBOutlet var ButtonToppic25: UIButton!
    
    @IBOutlet var LabelTopic3: UILabel!
    @IBOutlet var ButtonToppic31: UIButton!
    @IBOutlet var ButtonToppic32: UIButton!
    @IBOutlet var ButtonToppic33: UIButton!
    @IBOutlet var ButtonToppic34: UIButton!
    @IBOutlet var ButtonToppic35: UIButton!
    @IBOutlet var ButtonToppic36: UIButton!
    
    @IBOutlet var LabelTopic4: UILabel!
    @IBOutlet var ButtonToppic41: UIButton!
    @IBOutlet var ButtonToppic42: UIButton!
    @IBOutlet var ButtonToppic43: UIButton!
    @IBOutlet var ButtonToppic44: UIButton!
    
    @IBOutlet var LabelTopic5: UILabel!
    @IBOutlet var ButtonToppic51: UIButton!
    @IBOutlet var ButtonToppic52: UIButton!
    @IBOutlet var ButtonToppic53: UIButton!
    @IBOutlet var ButtonToppic54: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        TextTopics()
        Buttons()

    }
    
    func TextTopics() {
        
        LabelTopic1.text = "Line: First Step"
        LabelTopic2.text = "Line: Two points"
        LabelTopic3.text = "Line: Linears equations"
        LabelTopic4.text = "Line: Slopes"
        LabelTopic5.text = "Line: Quizes"

    }

    
    func Buttons() {
        
        ButtonToppic14.isHidden = true
        ButtonToppic15.isHidden = true
        
        BackButton.setTitle("←", for: .normal)
        
        ButtonToppic11.setTitle("- What's a line? 📼", for: .normal)
        ButtonToppic12.setTitle("- Why is important to study lines? 📄", for: .normal)
        ButtonToppic13.setTitle("- What's the cartesian plane? 📄", for: .normal)
        ButtonToppic14.setTitle("- The representation of a line 📄", for: .normal)
        ButtonToppic15.setTitle("- First view of linear equations 📄", for: .normal)
        ButtonToppic16.setTitle("- First work: The equation of a line 📝", for: .normal)
        
        ButtonToppic21.setTitle("- What's a point? 📼", for: .normal)
        ButtonToppic22.setTitle("- What can represent a point? 📄", for: .normal)
        ButtonToppic23.setTitle("- Importance of the points 📄", for: .normal)
        ButtonToppic24.setTitle("- Points and lines 📄", for: .normal)
        ButtonToppic25.setTitle("- Second work: Second equation of a line 📝", for: .normal)
         
        ButtonToppic31.setTitle("- The linear equation in the world 📼", for: .normal)
        ButtonToppic32.setTitle("- Introduction to vectors 📄", for: .normal)
        ButtonToppic33.setTitle("- Directions 📄", for: .normal)
        ButtonToppic34.setTitle("- Magnitud 📄", for: .normal)
        ButtonToppic35.setTitle("- The linear equation 📄", for: .normal)
        ButtonToppic36.setTitle("- Third work: the linear equations 📝", for: .normal)
         
        ButtonToppic41.setTitle("- What's a slope? 📼", for: .normal)
        ButtonToppic42.setTitle("- Importance of a slope 📄", for: .normal)
        ButtonToppic43.setTitle("- Line-Slope linear equation 📄", for: .normal)
        ButtonToppic44.setTitle("- Forth work: the line-slope linear equation 📝", for: .normal)
         
        ButtonToppic51.setTitle("- Quiz 1: First Step 📝", for: .normal)
        ButtonToppic52.setTitle("- Quiz 2: Two points 📝", for: .normal)
        ButtonToppic53.setTitle("- Quiz 3: Linears equations 📝", for: .normal)
        ButtonToppic54.setTitle("- Quiz 4: Slope 📝", for: .normal)

    }
}

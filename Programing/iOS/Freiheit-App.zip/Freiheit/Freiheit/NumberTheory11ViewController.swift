import UIKit

class NumberTheory11ViewController: UIViewController {
    
    @IBOutlet var VideoText: UILabel!
    @IBOutlet var VideoButton: UIButton!
    
    @IBOutlet var TopicTitleText: UILabel!
    @IBOutlet var Text: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        updateUI()
        
    }
    
    func updateUI() {
        VideoText.isHidden = true
        
        VideoText.text = "Sorry, for the moment is not disponible this video"
        
        TopicTitleText.text = "Introduction to the concept of a line"
        Text.text = "The line is a fundamental concept in mahth, but so dificult to define. Usually we define it, like the geometric place given the direct union of two points. It doesn't look too complicated, right? Well, when we try to define wht'ss a point, we used to say that is the geometric place where two non-parallels lines intersect them. This means that a line is define by points, and points are defined by lines. That's a bigest mistake! But for now, we only have to know that a line is someting that go away in una direction."
        
    }
    
    @IBAction func PressButton(_ sender:Any) {
        VideoText.isHidden = false
        VideoButton.isHidden = true
        
    }
    
}

import UIKit

class TopicsViewController: UIViewController {

    @IBOutlet var InfoLobbyStack: UIStackView!
    @IBOutlet var JoinClassButton: UIButton!
    @IBOutlet var TitleTextLobby: UILabel!
    @IBOutlet var SubtextLobby: UILabel!

    @IBOutlet var NewTopicStack: UIStackView!
    @IBOutlet var SearchTopic: UITextField!
    @IBOutlet var TopicNewTitle1: UILabel!
    @IBOutlet var TopicButtonNew1: UIButton!
    @IBOutlet var TopicNewTitle2: UILabel!
    @IBOutlet var TopicButtonNew2: UIButton!
    @IBOutlet var TopicNewTitle3: UILabel!
    @IBOutlet var TopicButtonNew3: UIButton!
    
    @IBOutlet var TopicsStacks: UIStackView!
    @IBOutlet var TitleTopicText: UILabel!

    @IBOutlet var TopicTitle1: UILabel!
    @IBOutlet var TopicTitle2: UILabel!
    @IBOutlet var TopicTitle3: UILabel!
    @IBOutlet var TopicTitle4: UILabel!
    @IBOutlet var TopicTitle5: UILabel!
    @IBOutlet var TopicTitle6: UILabel!
    @IBOutlet var TopicTitle7: UILabel!
    
    @IBOutlet var TopicButton1: UIButton!
    @IBOutlet var TopicButton2: UIButton!
    @IBOutlet var TopicButton3: UIButton!
    @IBOutlet var TopicButton4: UIButton!
    @IBOutlet var TopicButton5: UIButton!
    @IBOutlet var TopicButton6: UIButton!
    @IBOutlet var TopicButton7: UIButton!

    @IBOutlet var ImagenTopic1: UIImageView!
    @IBOutlet var ImagenTopic2: UIImageView!
    @IBOutlet var ImagenTopic3: UIImageView!
    @IBOutlet var ImagenTopic4: UIImageView!
    @IBOutlet var ImagenTopic5: UIImageView!
    @IBOutlet var ImagenTopic6: UIImageView!
    @IBOutlet var ImagenTopic7: UIImageView!

    var countpressed = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
        Buttons()
        
        SearchTopic.backgroundColor = UIColor.init(red: 0, green: 0, blue: 1, alpha: 1)
        SearchTopic.layer.cornerRadius = 25.0
        SearchTopic.tintColor = UIColor.black
        
        JoinClassButton.backgroundColor = UIColor.init(red: 0, green: 0, blue: 1, alpha: 1)
        JoinClassButton.layer.cornerRadius = 25.0
        JoinClassButton.tintColor = UIColor.black
    }

    func updateUI() {
/*        JoinClassButton.setTitle("Join Class")*/

        InfoLobbyStack.isHidden = false
        NewTopicStack.isHidden = true
        TopicsStacks.isHidden = false
        
        TitleTextLobby.text = "Need to add a class?"
        SubtextLobby.text = "Joing using email and continue your's taks"
        
        TitleTopicText.text = "Recent lessons"
       
        SearchTopic.text = "🔍 Search a new topic"
                
        TopicNewTitle1.text = "Divisibility, fractions, modular arithmetic, analityc number theory, algebraic number theory, cuadratic forms, L-functions"
        TopicNewTitle2.text = "Definide continuity, differentiation and derivative, graphs and theorems, pre-integral calculus"
        TopicNewTitle3.text = "Introduction, Euclid's postulates, elemental geometry, angles, basics spaces regions, identities"
        
        TopicTitle1.text = "Linear equations, slopes of a line, and general equations"
        TopicTitle2.text = "Linear equations, slopes of a line, and general equations"
        TopicTitle3.text = "Advanced algebra and pre-calculus"
        TopicTitle4.text = "Advanced algebra and pre-calculus"
        TopicTitle5.text = "Differential Calculus"
        TopicTitle6.text = "Differential Calculus"
        TopicTitle7.text = "Differential Calculus"
    }
   
    func Buttons() {
        JoinClassButton.setTitle("Join class", for: .normal)
        
        TopicButtonNew1.setTitle("Number Theory", for: .normal)
        TopicButtonNew2.setTitle("Integral Calculus", for: .normal)
        TopicButtonNew3.setTitle("Geometry", for: .normal)

        TopicButton1.setTitle("Line: First Step", for: .normal)
        TopicButton2.setTitle("Line: Two Points", for: .normal)
        TopicButton3.setTitle("Line: Linear Equation", for: .normal)
        TopicButton4.setTitle("Line: Slope", for: .normal)
        TopicButton5.setTitle("Dirivative: Limits and Continuity", for: .normal)
        TopicButton6.setTitle("Dirivative: Definition of derivatives", for: .normal)
        TopicButton7.setTitle("Derivative Rules", for: .normal)
    }
    
    @IBAction func AddAClass(_ sender: Any) {
        countpressed += 1
        if (countpressed%2==0) {
            NewTopicStack.isHidden = true
/*          TopicTitle1.isHidden = false
            ImagenTopic1.isHidden = false
            TopicButton1.isHidden = false
            TopicTitle2.isHidden = false
            ImagenTopic2.isHidden = false
            TopicButton2.isHidden = false
            TopicTitle3.isHidden = false
            ImagenTopic3.isHidden = false
            TopicButton3.isHidden = false*/
            TopicTitle4.isHidden = false
            ImagenTopic4.isHidden = false
            TopicButton4.isHidden = false
            TopicTitle5.isHidden = false
            ImagenTopic5.isHidden = false
            TopicButton5.isHidden = false
            TopicTitle6.isHidden = false
            ImagenTopic6.isHidden = false
            TopicButton6.isHidden = false
            TopicTitle7.isHidden = false
            ImagenTopic7.isHidden = false
            TopicButton7.isHidden = false
        } else {
            NewTopicStack.isHidden = false
/*          TopicTitle1.isHidden = true
            ImagenTopic1.isHidden = true
            TopicButton1.isHidden = true
            TopicTitle2.isHidden = true
            ImagenTopic2.isHidden = true
            TopicButton2.isHidden = true
            TopicTitle3.isHidden = true
            ImagenTopic3.isHidden = true
            TopicButton3.isHidden = true*/
            TopicTitle4.isHidden = true
            ImagenTopic4.isHidden = true
            TopicButton4.isHidden = true
            TopicTitle5.isHidden = true
            ImagenTopic5.isHidden = true
            TopicButton5.isHidden = true
            TopicTitle6.isHidden = true
            ImagenTopic6.isHidden = true
            TopicButton6.isHidden = true
            TopicTitle7.isHidden = true
            ImagenTopic7.isHidden = true
            TopicButton7.isHidden = true
        }
    }
 
}

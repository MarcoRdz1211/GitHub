import UIKit

class NumberTheory16ViewController: UIViewController {

    @IBOutlet var TitleText: UILabel!
    
    @IBOutlet var FirstQuestion: UILabel!
    
    @IBOutlet var FirstAnswer1: UILabel!
    @IBOutlet var FirstButtonAnswer1: UISwitch!
    
    @IBOutlet var FirstAnswer2: UILabel!
    @IBOutlet var FirstButtonAnswer2: UISwitch!
    
    @IBOutlet var FirstAnswer3: UILabel!
    @IBOutlet var FirstButtonAnswer3: UISwitch!

    @IBOutlet var FirstAnswer4: UILabel!
    @IBOutlet var FirstButtonAnswer4: UISwitch!
    
    @IBOutlet var SecondQuestion: UILabel!
    @IBOutlet var SecondAnswer: UITextField!
    
    
    @IBOutlet var ThirdQuestion: UILabel!
    
    @IBOutlet var ThirdButtonAnswer1: UIButton!
    @IBOutlet var ThirdAnswer1: UILabel!
    
    @IBOutlet var ThirdButtonAnswer2: UIButton!
    @IBOutlet var ThirdAnswer2: UILabel!
    
    @IBOutlet var ThirdButtonAnswer3: UIButton!
    @IBOutlet var ThirdAnswer3: UILabel!
    
    @IBOutlet var ThirdButtonAnswer4: UIButton!
    @IBOutlet var ThirdAnswer4: UILabel!
    
    @IBOutlet var ThirdButtonAnswer5: UIButton!
    @IBOutlet var ThirdAnswer5: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()

    }
    
    func updateUI() {
        TitleText.text = "Quiz 1"
        
        FirstQuestion.text = "Select wich equations can represent a linear equation"
        
        FirstAnswer1.text = "x^2+3x-y=0"
        FirstAnswer2.text = "x-y+1000=5"
        FirstAnswer3.text = "x/y+5=0"
        FirstAnswer4.text = "x^(1/2)+y=2"
        
        
        SecondQuestion.text = "Write the linear equation of the line with slope 3 and y-axis's intercection in: y=-10"
        
        SecondAnswer.text = "Ay+Bx+C=0"
        
        
        ThirdQuestion.text = "Press the option that you think are the linears form"
        
        ThirdAnswer1.isHidden = true
        ThirdAnswer2.isHidden = true
        ThirdAnswer3.isHidden = true
        ThirdAnswer4.isHidden = true
        ThirdAnswer5.isHidden = true

        ThirdAnswer1.text = "Incorrect"
        ThirdAnswer2.text = "Correct"
        ThirdAnswer3.text = "Incorrect"
        ThirdAnswer4.text = "Correct"
        ThirdAnswer5.text = "Incorrect"
    }
    
    func Buttons() {
        ThirdButtonAnswer1.setTitle("Cuadratic form", for: .normal)
        ThirdButtonAnswer2.setTitle("Slope-intersection", for: .normal)
        ThirdButtonAnswer3.setTitle("Integral form", for: .normal)
        ThirdButtonAnswer4.setTitle("Dot-Slope", for: .normal)
        ThirdButtonAnswer5.setTitle("Non-linear form", for: .normal)
    }

    @IBAction func PressButton1(_ sender: Any) {
        ThirdAnswer1.isHidden = false
    }
    
    @IBAction func PressButton2(_ sender: Any) {
        ThirdAnswer2.isHidden = false
    }
    
    @IBAction func PressButton3(_ sender: Any) {
        ThirdAnswer3.isHidden = false
    }
    
    @IBAction func PressButton4(_ sender: Any) {
        ThirdAnswer4.isHidden = false
    }
    
    @IBAction func PressButton5(_ sender: Any) {
        ThirdAnswer5.isHidden = false
    }
    
    
}
